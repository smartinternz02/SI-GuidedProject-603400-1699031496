from flask import Flask, render_template, request
import numpy as np
import pickle


app = Flask(__name__)

model = pickle.load(open('ar_xgb.pkl','rb'))
ss1 = pickle.load(open('ar_ss.pkl','rb'))
#le9 = pickle.load(open('le9.pkl','rb'))
#le10 = pickle.load(open('le10.pkl','rb'))


@app.route("/")
def about():
    return render_template('home.html')


@app.route("/home")
def home():
    return render_template('home.html')


@app.route("/predict")
def home1():
    return render_template('predict.html')


@app.route("/submit")
def home2():
    return render_template('submit.html')


@app.route("/pred", methods=['POST'])
def predict():
    seat = request.form['Seat']
    seat = int(seat)
    food = request.form['Food']
    food = int(food)
    ground = request.form['Ground']
    ground = int(ground)
    value = request.form['Value']
    value = int(value)
    over = request.form['Over']
    over = int(over)
    
    data = [seat,food,ground,over,value]
    print(data)
    pred = model.predict(ss1.transform([data]))
    
    if pred==0:
        text = 'NOT RECOMMENDED'
    else:
        text = 'RECOMMENDED'
    print(text)

    return render_template('submit.html', prediction=text)



"""i = [x for x in request.form.values()]
    f = [np.array(i)]
    print(f)
    output = model.predict(f)"""


'''@app.route('/predicts',methods =['GET','POST'])
def predicts():
    
    return render_template('index.html', prediction_text = 'Suitable drug type is {}'.format(prediction))'''



if __name__ == "__main__":
    app.run(debug=False)